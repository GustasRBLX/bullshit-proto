#include "Convert.h"

DWORD Renv = 0;

DWORD WINAPI input(PVOID lvpParameter)
{
	std::string WholeScript = "";
	HANDLE hPipe;
	char buffer[999999];
	DWORD dwRead;
	hPipe = CreateNamedPipe(TEXT("\\\\.\\pipe\\Axon"), //its protoconversion lol but ok
		PIPE_ACCESS_DUPLEX | PIPE_TYPE_BYTE | PIPE_READMODE_BYTE,
		PIPE_WAIT,
		1,
		999999,
		999999,
		NMPWAIT_USE_DEFAULT_WAIT,
		NULL);
	while (hPipe != INVALID_HANDLE_VALUE)
	{
		if (ConnectNamedPipe(hPipe, NULL) != FALSE)
		{
			while (ReadFile(hPipe, buffer, sizeof(buffer) - 1, &dwRead, NULL) != FALSE)
			{
				buffer[dwRead] = '\0';
				try {
					try {
						WholeScript = WholeScript + buffer;
					}
					catch (...) {
					}
				}
				catch (std::exception e) {

				}
				catch (...) {

				}
			}

			auto* L = luaL_newstate();
			DWORD luaState = RLua.lua_newthread(Renv);
		
			int identity[] = { 6 };
			int unk[] = { 0, 0 };
			Sandbox(luaState, identity, unk);
			zx3::Conversion::ExecuteScript(L, luaState, WholeScript);

			WholeScript = "";
		}
		DisconnectNamedPipe(hPipe);
	}
}


const char* GetClass(int self)
{
	return (const char*)(*(int(**)(void))(*(int*)self + 16))();
}


int FindFirstClass(int Instance, const char* Name)
{
	DWORD CHILD_START = *(DWORD*)(Instance + 0x2C);
	DWORD CHILD_END = *(DWORD*)(CHILD_START + 4);

	for (int i = *(int*)CHILD_START; i != CHILD_END; i += 8)
	{
		if (memcmp(GetClass(*(int*)i), Name, strlen(Name)) == 0)
		{
			return *(int*)i;
		}
	}
}



using gmDataModelFn = void* (__stdcall*)(void* md);
extern gmDataModelFn GetDataModel;

gmDataModelFn GetDataModel = reinterpret_cast<gmDataModelFn>(SignatureFind::Addresses::RobloxBase(0xe3e4d0));
namespace scanner {
	BOOL compare(const BYTE* location, const BYTE* aob, const char* mask) {
		for (; *mask; ++aob, ++mask, ++location) {
			__try {
				if (*mask == 'x' && *location != *aob)
					return 0;
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				return 0;
			}
		}
		return 1;
	}

	DWORD find_Pattern(DWORD size, BYTE * pattern, char* mask,
		BYTE protection = (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) {
		SYSTEM_INFO SI = { 0 };
		GetSystemInfo(&SI);
		DWORD start = (DWORD)SI.lpMinimumApplicationAddress;
		DWORD end = (DWORD)SI.lpMaximumApplicationAddress;
		MEMORY_BASIC_INFORMATION mbi;
		while (start < end && VirtualQuery((void*)start, &mbi, sizeof(mbi))) {
			// Make sure the memory is committed, matches our protection, and isn't PAGE_GUARD.
			if ((mbi.State & MEM_COMMIT) && (mbi.Protect & protection) && !(mbi.Protect & PAGE_GUARD)) {
				// Scan all the memory in the region.
				for (DWORD i = (DWORD)mbi.BaseAddress; i < (DWORD)mbi.BaseAddress + mbi.RegionSize; ++i) {
					if (compare((BYTE*)i, pattern, mask)) {
						return i;
					}
				}
			}
			// Move onto the next region of memory.
			start += mbi.RegionSize;
		}
		return 0;
	}

	int Scan(DWORD mode, char* content, char* mask) {
		return find_Pattern(0x7FFFFFFF, (BYTE*)content, mask, mode);
	}
}
void maininit()
{
	//auto* L = luaL_newstate();
	
	DWORD scvft = SignatureFind::Addresses::RobloxBase(0x1A28080); //tf is this addy

	DWORD ScriptContext = scanner::Scan(PAGE_READWRITE, (char*)&scvft, (char*)"xxxx");
	
	Renv = *(DWORD*)(ScriptContext + 56 * 0 + 164) - (ScriptContext + 56 * 0 + 164);
	
	int newthread = RLua.lua_newthread(Renv);
	
	CreateThread(nullptr, 0, (LPTHREAD_START_ROUTINE)input, nullptr, 0, nullptr);

	std::string source;
	while (std::getline(std::cin, source)) {
		auto* L = luaL_newstate();
		DWORD luaState = RLua.lua_newthread(Renv);

		int identity[] = { 6 };
		int unk[] = { 0, 0 };
		Sandbox(luaState, identity, unk);
		zx3::Conversion::ExecuteScript(L, luaState, source);
	}
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DWORD c = 0;
		VirtualProtect(FreeConsole, 1, PAGE_EXECUTE_READWRITE, &c);
		*reinterpret_cast<UINT*>(FreeConsole) = 0xC3;
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
		freopen("CONIN$", "r", stdin);
		CreateThread(nullptr, 0, (LPTHREAD_START_ROUTINE)maininit, nullptr, 0, nullptr);
	}
	return 1;
}