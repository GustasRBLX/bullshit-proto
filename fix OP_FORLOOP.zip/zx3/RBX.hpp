#pragma once
#include <Windows.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include "Retcheck.h"

namespace SignatureFind
{
    namespace Addresses
    {
        uintptr_t RobloxBase(uintptr_t address)
        {
            return (address - 0x400000 + reinterpret_cast<DWORD>(GetModuleHandle(0)));
        }
    }
}

using spawnFn = void(__cdecl*)(uintptr_t rL);
spawnFn r_spawn = (spawnFn)SignatureFind::Addresses::RobloxBase(0x72d210);
using sandboxFn = void(__cdecl*)(uintptr_t, int[], int[]);
sandboxFn Sandbox = (sandboxFn)SignatureFind::Addresses::RobloxBase(0x72ceb0);

namespace zx3
{
    class RbxLua
    {
    public:
        static DWORD luaF_newproto(uintptr_t rL)
        {
            return ((DWORD(__cdecl*)(uintptr_t rL))SignatureFind::Addresses::RobloxBase(0x11D3370))(rL);
        }
        static const char* luaS_newlstr(uintptr_t rL, const char* str, size_t Size)
        {
            using luaS_newlstrFn = const char* (__cdecl*)(uintptr_t rL, const char* str, size_t length);
            luaS_newlstrFn r_newlstr = reinterpret_cast<luaS_newlstrFn>(SignatureFind::Addresses::RobloxBase(0x11D4770));
            return r_newlstr(rL, str, Size);
        }

        static int lua_newthread(uintptr_t rL)
        {
            return ((int(__cdecl*)(uintptr_t))unprotect(SignatureFind::Addresses::RobloxBase(0x11C0610)))(rL);
        }

        int __cdecl luaF_newLClosure(int a1, int a2, int a3)
        {
            int v1{};

            *(DWORD*)(v1 + 28) = v1 + 28;
            *(DWORD*)(v1 + 68) = 0;
            *(DWORD*)(v1 + 32) = v1 + 32;
            *(DWORD*)(v1 + 56) = 0;
            *(DWORD*)(v1 + 16) = v1 + 16;
            *(DWORD*)(v1 + 76) = 0;
            *(DWORD*)(v1 + 72) = 0;
            *(BYTE*)(v1 + 83) = 0;
            *(DWORD*)(v1 + 20) = v1 + 20;
            *(WORD*)(v1 + 81) = 0;
            *(BYTE*)(v1 + 80) = 0;
            *(DWORD*)(v1 + 60) = 0;
            *(DWORD*)(v1 + 52) = 0;
            *(DWORD*)(v1 + 12) = v1 + 12;
            *(DWORD*)(v1 + 36) = v1 + 36;
            *(DWORD*)(v1 + 64) = 0;
            *(DWORD*)(v1 + 8) = v1 + 8;
            *(DWORD*)(v1 + 24) = v1 + 24;
            *(DWORD*)(v1 + 40) = -(v1 + 40);
            *(DWORD*)(v1 + 44) = v1 + 44;
            return *(DWORD*)v1;
        }
    };
}

namespace zx3
{
    namespace Obfuscation
    {
        void ObfuscateProto(uintptr_t a1, uintptr_t m)
        {
            *reinterpret_cast<uintptr_t*>(a1) = m ^ a1;
        }
        namespace GlobalState
        {
            void DeObfuscateGL(uintptr_t a1)
            {
                reinterpret_cast<uintptr_t*>(a1) - *reinterpret_cast<uintptr_t*>(a1);
            }
        }
    }
}